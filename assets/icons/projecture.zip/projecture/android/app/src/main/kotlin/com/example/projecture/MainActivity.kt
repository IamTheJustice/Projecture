package com.example.projecture

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
