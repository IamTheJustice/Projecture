import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';

class OrderSummeryViewModel extends GetxController {
  RxList<Map<String, dynamic>> list1 = <Map<String, dynamic>>[
    {
      "imagepath": "assets/icons/android.png",
      "title": 'Android',
      "isSelect": false
    },
    {
      "imagepath": "assets/icons/flutter.png",
      "title": 'Flutter',
      "isSelect": false
    },
    {"imagepath": "assets/icons/ios.png", "title": 'IOS', "isSelect": false},
    {"imagepath": "assets/icons/php.png", "title": 'PHP', "isSelect": false},
    {"imagepath": "assets/icons/node.png", "title": 'Node', "isSelect": false},
  ].obs;
  List selection = [];

  void Selection({required String value}) {
    if (selection.contains(value)) {
      selection.remove(value);
    } else {
      selection.add(value);
    }
    update();
  }
}
