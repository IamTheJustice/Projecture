import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:sizer/sizer.dart';

import '../../utils/color_utils.dart';

class CheckingScreen extends StatefulWidget {
  const CheckingScreen({Key? key}) : super(key: key);

  @override
  State<CheckingScreen> createState() => _CheckingScreenState();
}

class _CheckingScreenState extends State<CheckingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: const IconThemeData(color: ColorUtils.white),
        title: const Text("Checking"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 2.w, vertical: 3.w),
        child: ScrollConfiguration(
          behavior: const ScrollBehavior().copyWith(overscroll: false),
          child: SingleChildScrollView(
            child: Column(
              children: [
                ListView.builder(
                  shrinkWrap: true,
                  scrollDirection: Axis.vertical,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: 20,
                  itemBuilder: (BuildContext context, int index) {
                    return Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 2.w, horizontal: 5.w),
                      child: Slidable(
                        key: const ValueKey(0),
                        endActionPane: ActionPane(
                          motion: GestureDetector(
                              onTap: () {
                                Navigator.push(
                                    context,
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            const ShowTaskChecking()));
                              },
                              child: Container(
                                height: 18.w,
                                margin: EdgeInsets.only(left: 3.sp),
                                decoration: BoxDecoration(
                                  color: ColorUtils.green2A.withOpacity(0.5),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Center(
                                  child: Text(
                                    "Show \nTask",
                                    style:
                                        FontTextStyle.Proxima16Medium.copyWith(
                                            color: ColorUtils.white,
                                            fontWeight: FontWeightClass.semiB),
                                  ),
                                ),
                              )),
                          extentRatio: .3,
                          dragDismissible: false,
                          children: const [],
                        ),
                        child: Container(
                          height: 18.w,
                          width: Get.width,
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10.0)),
                              color: ColorUtils.purple),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 5.w, vertical: 3.w),
                            child: Text(
                              "Firebase project",
                              overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                              style: FontTextStyle.Proxima16Medium.copyWith(
                                  color: ColorUtils.white,
                                  decoration: TextDecoration.underline),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class ShowTaskChecking extends StatefulWidget {
  const ShowTaskChecking({Key? key}) : super(key: key);

  @override
  State<ShowTaskChecking> createState() => _ShowTaskCheckingState();
}

class _ShowTaskCheckingState extends State<ShowTaskChecking> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Show Task"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 3.w),
        child: Container(
          height: 30.w,
          width: 40.w,
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                    blurRadius: 9.0,
                    color: ColorUtils.black.withOpacity(0.2),
                    spreadRadius: 0.5),
              ],
              borderRadius: const BorderRadius.all(Radius.circular(10.0)),
              color: ColorUtils.purple),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Firebase project",
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  style: FontTextStyle.Proxima16Medium.copyWith(
                      color: ColorUtils.white,
                      decoration: TextDecoration.underline),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
