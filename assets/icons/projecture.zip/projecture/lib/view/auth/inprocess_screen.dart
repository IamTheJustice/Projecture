import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:sizer/sizer.dart';

class Process extends StatefulWidget {
  const Process({Key? key}) : super(key: key);

  @override
  State<Process> createState() => _ProcessState();
}

class _ProcessState extends State<Process> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Project List"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: ScrollConfiguration(
        behavior: const ScrollBehavior().copyWith(overscroll: false),
        child: SingleChildScrollView(
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            itemCount: 5,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 5.w),
                child: Slidable(
                  key: const ValueKey(0),
                  endActionPane: ActionPane(
                    motion: GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const ShowTaskProcess()));
                        },
                        child: Container(
                          height: 18.w,
                          margin: EdgeInsets.only(left: 3.sp),
                          decoration: BoxDecoration(
                            color: ColorUtils.green2A.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text(
                              "Show \nTask",
                              style: FontTextStyle.Proxima16Medium.copyWith(
                                  color: ColorUtils.white,
                                  fontWeight: FontWeightClass.semiB),
                            ),
                          ),
                        )),
                    extentRatio: .3,
                    dragDismissible: false,
                    children: const [],
                  ),
                  child: Container(
                    height: 18.w,
                    width: Get.width,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        color: ColorUtils.purple),
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
                      child: Text(
                        "Firebase project",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: FontTextStyle.Proxima16Medium.copyWith(
                            color: ColorUtils.white,
                            decoration: TextDecoration.underline),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class ShowTaskProcess extends StatefulWidget {
  const ShowTaskProcess({Key? key}) : super(key: key);

  @override
  State<ShowTaskProcess> createState() => _ShowTaskProcessState();
}

class _ShowTaskProcessState extends State<ShowTaskProcess> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Show Task"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 3.w),
        child: Container(
          height: 40.w,
          width: 40.w,
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                    blurRadius: 9.0,
                    color: ColorUtils.black.withOpacity(0.2),
                    spreadRadius: 0.5),
              ],
              borderRadius: const BorderRadius.all(Radius.circular(10.0)),
              color: ColorUtils.purple),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Firebase project",
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  style: FontTextStyle.Proxima16Medium.copyWith(
                      color: ColorUtils.white,
                      decoration: TextDecoration.underline),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    InkWell(
                      onTap: () {
                        showDialog(
                            context: context,
                            builder: (context) {
                              return AlertDialog(
                                title: Column(
                                  children: [
                                    Text(
                                      'Start Task',
                                      style: FontTextStyle.Proxima16Medium
                                          .copyWith(
                                              color: ColorUtils.primaryColor,
                                              fontWeight:
                                                  FontWeightClass.extraB,
                                              fontSize: 13.sp),
                                    ),
                                    Lottie.asset(
                                        "assets/images/processLottie.json",
                                        width: 50.w),
                                  ],
                                ),
                                content: Text(
                                    'are you sure want to start Task?',
                                    textAlign: TextAlign.center,
                                    style:
                                        FontTextStyle.Proxima16Medium.copyWith(
                                            color: ColorUtils.primaryColor)),
                                actions: [
                                  InkWell(
                                    onTap: () {
                                      Get.back();
                                      Get.showSnackbar(
                                        GetSnackBar(
                                          message: "Start Task Succesfully",
                                          borderRadius: 10.0,
                                          margin: EdgeInsets.only(
                                              left: 4.w,
                                              right: 4.w,
                                              bottom: 4.w),
                                          snackPosition: SnackPosition.BOTTOM,
                                          backgroundColor: ColorUtils
                                              .primaryColor
                                              .withOpacity(0.9),
                                          duration: const Duration(seconds: 3),
                                        ),
                                      );
                                    },
                                    child: Container(
                                      height: 10.w,
                                      width: 25.w,
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: ColorUtils.primaryColor),
                                      child: const Center(
                                        child: Text(
                                          "Done",
                                          style: TextStyle(
                                              color: ColorUtils.white),
                                        ),
                                      ),
                                    ),
                                  ),
                                  InkWell(
                                    onTap: () {
                                      Get.back();
                                    },
                                    child: Container(
                                      height: 10.w,
                                      width: 25.w,
                                      decoration: const BoxDecoration(
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(8.0)),
                                          color: ColorUtils.primaryColor),
                                      child: const Center(
                                        child: Text(
                                          "Cancle",
                                          style: TextStyle(
                                              color: ColorUtils.white),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              );
                            });
                      },
                      child: Text(
                        "Start",
                        style: FontTextStyle.Proxima16Medium.copyWith(
                            color: ColorUtils.white,
                            fontSize: 13.sp,
                            fontWeight: FontWeightClass.semiB),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
