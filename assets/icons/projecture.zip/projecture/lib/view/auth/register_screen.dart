import 'package:flutter/material.dart';
import 'package:flutter_animated_button/flutter_animated_button.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:projecture/utils/size_config_utils.dart';
import 'package:projecture/view/auth/Login_screen.dart';
import 'package:sizer/sizer.dart';

class RegisterScreen extends StatefulWidget {
  const RegisterScreen({Key? key}) : super(key: key);

  @override
  State<RegisterScreen> createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  final formkey = GlobalKey<FormState>();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController dateController = TextEditingController();
  final TextEditingController confirmPasswordController =
      TextEditingController();
  DateTime date = DateTime.now();
  late var formattedDate = "Date of Birth";
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => FocusManager.instance.primaryFocus?.unfocus(),
      behavior: HitTestBehavior.translucent,
      child: Scaffold(
        // resizeToAvoidBottomInset: false,
        backgroundColor: ColorUtils.white,
        body: SingleChildScrollView(
          child: Form(
            key: formkey,
            child: Column(
              children: [
                Stack(
                  children: [
                    Image.asset("assets/images/background.png"),
                    Padding(
                      padding: EdgeInsets.symmetric(vertical: 15.w),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset(
                            'assets/icons/logo.png',
                            color: ColorUtils.white,
                            height: 9.w,
                            width: 12.w,
                          ),
                          Text(
                            "Projecture",
                            style: FontTextStyle.Proxima16Medium.copyWith(
                                color: ColorUtils.white,
                                fontSize: 15.sp,
                                fontWeight: FontWeightClass.extraB),
                          )
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 45.w),
                      child: Container(
                        height: 20.w,
                        width: Get.width,
                        decoration: const BoxDecoration(
                            color: ColorUtils.white,
                            borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(90.0))),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "Register",
                              style: FontTextStyle.Proxima16Medium.copyWith(
                                  fontSize: 18.sp,
                                  color: ColorUtils.primaryColor,
                                  fontWeight: FontWeightClass.semiB),
                            ),
                            Text(
                              "create your account",
                              style: FontTextStyle.Proxima14Regular.copyWith(
                                  color: ColorUtils.primaryColor,
                                  fontWeight: FontWeightClass.semiB),
                            ),
                          ],
                        ),
                      ),
                    )
                  ],
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    validator: (v) {
                      if (v!.isEmpty) {
                        return "please name required";
                      } else if (!RegExp(r'^[a-zA-Z]+$').hasMatch(v)) {
                        return "please valid name ";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "Full Name",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    validator: (v) {
                      if (v!.isEmpty) {
                        return "please city required";
                      } else if (!RegExp(r'^[a-zA-Z]+$').hasMatch(v)) {
                        return "please valid cityname ";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "City",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    validator: (v) {
                      if (v!.isEmpty) {
                        return "please company name required";
                      } else if (!RegExp(r'^[a-zA-Z]+$').hasMatch(v)) {
                        return "please valid company name ";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "Company Name",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    validator: (v) {
                      if (v!.isEmpty) {
                        return "please email required";
                      } else if (!RegExp(
                              r"^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                              r"{0,253}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]"
                              r"{0,253}[a-zA-Z0-9])?)*$")
                          .hasMatch(v)) {
                        return "please enter valid email ";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "Email/Username",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    controller: passwordController,
                    validator: (v) {
                      // add your custom validation here.
                      if (v!.isEmpty) {
                        return 'Please enter password';
                      }
                      if (v.length <= 8) {
                        return 'Password must be atleast 8 characters long';
                      }
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "Password",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    controller: dateController,
                    readOnly: true,
                    validator: (v) {
                      if (v == null || v.isEmpty) {
                        return "please required date";
                      }
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "${formattedDate}",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                    onTap: () async {
                      await showDatePicker(
                        context: context,
                        initialDate: date,
                        firstDate: DateTime(2022),
                        lastDate: DateTime(2030),
                      ).then((selectedDate) {
                        // if (selectedDate != null) {
                        //   setState(() {
                        //     date = selectedDate;
                        //     formattedDate =
                        //         DateFormat('d-MMM-yy').format(selectedDate);
                        //   });
                        // }
                        if (selectedDate != null) {
                          formattedDate =
                              DateFormat('d-MMM-yy').format(selectedDate);
                          setState(() {
                            dateController.text = formattedDate;
                          });
                        }
                      });
                    },
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(left: 6.w, right: 6.w, top: 2.w),
                  child: TextFormField(
                    controller: confirmPasswordController,
                    validator: (v) {
                      if (v!.isEmpty) return 'Empty';
                      if (v != passwordController.text) return 'Not Match';
                      return null;
                    },
                    decoration: InputDecoration(
                        contentPadding: EdgeInsets.all(4.w),
                        filled: true,
                        fillColor: ColorUtils.greyE7.withOpacity(0.5),
                        hintText: "Confirm Password",
                        hintStyle: FontTextStyle.Proxima14Regular.copyWith(
                            color: ColorUtils.primaryColor),
                        border: const OutlineInputBorder(
                            borderSide: BorderSide.none,
                            borderRadius:
                                BorderRadius.all(Radius.circular(10.0)))),
                  ),
                ),
                SizeConfig.sH3,
                AnimatedButton(
                    height: 12.w,
                    width: 60.w,
                    text: "REGISTER",
                    textStyle: FontTextStyle.Proxima14Regular.copyWith(
                        fontSize: 12.sp, color: ColorUtils.white),
                    borderRadius: 10.0,
                    backgroundColor: ColorUtils.primaryColor,
                    selectedBackgroundColor: ColorUtils.purple,
                    transitionType: TransitionType.CENTER_ROUNDER,
                    selectedTextColor: ColorUtils.white,
                    isReverse: true,
                    onPress: () {
                      FocusScope.of(context).requestFocus();
                      if (formkey.currentState!.validate()) {
                        Get.showSnackbar(
                          GetSnackBar(
                            message: "Register Succesfully",
                            borderRadius: 10.0,
                            margin: EdgeInsets.only(
                                left: 4.w, right: 4.w, bottom: 4.w),
                            snackPosition: SnackPosition.BOTTOM,
                            backgroundColor: ColorUtils.primaryColor,
                            duration: const Duration(seconds: 2),
                          ),
                        );
                        Future.delayed(
                          const Duration(seconds: 3),
                          () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => const LoginScreen()),
                            );
                          },
                        );
                      }
                    }),
                SizeConfig.sH1,
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      "Do you have an account ?",
                      style: FontTextStyle.Proxima10Regular.copyWith(
                          color: ColorUtils.primaryColor,
                          fontWeight: FontWeightClass.semiB),
                    ),
                    TextButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) => const LoginScreen()),
                          );
                        },
                        child: Text(
                          "Sign In",
                          style: FontTextStyle.Proxima14Regular.copyWith(
                              color: ColorUtils.primaryColor,
                              fontWeight: FontWeightClass.semiB),
                        )),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
