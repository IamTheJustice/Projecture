import 'dart:io';
import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_button/flutter_animated_button.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:projecture/utils/size_config_utils.dart';
import 'package:sizer/sizer.dart';

class issue extends StatefulWidget {
  const issue({Key? key}) : super(key: key);

  @override
  State<issue> createState() => _issueState();
}

class _issueState extends State<issue> {
  var selectIndex = 0;
  File? imageFile;
  final formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => FocusManager.instance.primaryFocus?.unfocus(),
      behavior: HitTestBehavior.translucent,
      child: DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text("Project List"),
            centerTitle: true,
            backgroundColor: ColorUtils.primaryColor,
            iconTheme: const IconThemeData(color: ColorUtils.white),
            bottom: const TabBar(
              indicatorColor: ColorUtils.primaryColor,
              tabs: [
                Tab(text: "Solve Issue"),
                Tab(text: "Upload Issue"),
              ],
            ),
          ),
          body: Form(
            key: formkey,
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 2.h),
              child: TabBarView(
                children: [
                  ListView.builder(
                    shrinkWrap: true,
                    scrollDirection: Axis.vertical,
                    itemCount: 5,
                    itemBuilder: (BuildContext context, int index) {
                      return Padding(
                        padding: EdgeInsets.symmetric(
                            vertical: 2.w, horizontal: 5.w),
                        child: Container(
                          height: 24.w,
                          width: Get.width,
                          decoration: const BoxDecoration(
                              borderRadius:
                                  BorderRadius.all(Radius.circular(10.0)),
                              color: ColorUtils.purple),
                          child: Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 5.w, vertical: 3.w),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  "Firebase project",
                                  overflow: TextOverflow.ellipsis,
                                  maxLines: 2,
                                  style: FontTextStyle.Proxima16Medium.copyWith(
                                      color: ColorUtils.white,
                                      decoration: TextDecoration.underline),
                                ),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    InkWell(
                                      onTap: () {},
                                      child: Text(
                                        "Show Task",
                                        style: FontTextStyle.Proxima16Medium
                                            .copyWith(
                                                color: ColorUtils.white,
                                                fontSize: 13.sp,
                                                fontWeight:
                                                    FontWeightClass.semiB),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                  ListView(
                    padding: const EdgeInsets.all(0.0),
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(
                                left: 5.w, right: 5.w, top: 2.w),
                            child: TextFormField(
                              validator: (v) {
                                if (v!.isEmpty) {
                                  return "please name required";
                                } else if (!RegExp(r'^[a-zA-Z]+$')
                                    .hasMatch(v)) {
                                  return "please valid name ";
                                }
                                return null;
                              },
                              decoration: InputDecoration(
                                  contentPadding: EdgeInsets.all(4.w),
                                  filled: true,
                                  fillColor: ColorUtils.greyE7.withOpacity(0.5),
                                  hintText: "Name",
                                  hintStyle:
                                      FontTextStyle.Proxima14Regular.copyWith(
                                          color: ColorUtils.primaryColor),
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0)))),
                            ),
                          ),
                          Padding(
                            padding: EdgeInsets.symmetric(
                                horizontal: 5.w, vertical: 2.h),
                            child: DottedBorder(
                              dashPattern: const [6, 3, 2, 3],
                              color: ColorUtils.greyBB,
                              strokeWidth: 1,
                              strokeCap: StrokeCap.square,
                              padding: EdgeInsets.symmetric(vertical: 1.5.h),
                              child: Center(
                                child: Container(
                                  child: imageFile != null
                                      ? Container(
                                          width: 30.w,
                                          height: 30.w,
                                          decoration: BoxDecoration(
                                              shape: BoxShape.rectangle,
                                              color: Colors.white,
                                              image: DecorationImage(
                                                image: FileImage(imageFile!),
                                                fit: BoxFit.cover,
                                              )),
                                        )
                                      : Container(
                                          decoration: const BoxDecoration(
                                            shape: BoxShape.rectangle,
                                            image: DecorationImage(
                                              image: AssetImage(
                                                  "assets/images/profile.png"),
                                              fit: BoxFit.cover,
                                            ),
                                          ),
                                          height: 30.w,
                                          width: 30.w,
                                        ),
                                ),
                              ),
                            ),
                          ),
                          Center(
                              child: InkWell(
                            onTap: () {
                              chooseImageBottomSheet();
                            },
                            child: Text(
                              "Choose picture",
                              style: FontTextStyle.Proxima16Medium.copyWith(
                                  decoration: TextDecoration.underline,
                                  color: ColorUtils.primaryColor),
                            ),
                          )),
                          Padding(
                            padding: EdgeInsets.only(
                                left: 5.w, right: 5.w, top: 2.w),
                            child: TextFormField(
                              maxLines: 3,
                              validator: (v) {
                                if (v!.isEmpty) {
                                  return "please description required";
                                }
                                return null;
                              },
                              decoration: InputDecoration(
                                  contentPadding: EdgeInsets.all(4.w),
                                  filled: true,
                                  fillColor: ColorUtils.greyE7.withOpacity(0.5),
                                  hintText: "Description",
                                  hintStyle:
                                      FontTextStyle.Proxima14Regular.copyWith(
                                          color: ColorUtils.primaryColor),
                                  border: const OutlineInputBorder(
                                      borderSide: BorderSide.none,
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(10.0)))),
                            ),
                          ),
                          SizeConfig.sH2,
                          AnimatedButton(
                              height: 12.w,
                              width: 60.w,
                              text: "UPLOAD",
                              textStyle:
                                  FontTextStyle.Proxima14Regular.copyWith(
                                      fontSize: 12.sp, color: ColorUtils.white),
                              borderRadius: 10.0,
                              backgroundColor: ColorUtils.primaryColor,
                              selectedBackgroundColor: ColorUtils.purple,
                              transitionType: TransitionType.CENTER_ROUNDER,
                              selectedTextColor: ColorUtils.white,
                              isReverse: true,
                              onPress: () {
                                FocusScope.of(context).requestFocus();
                                if (formkey.currentState!.validate()) {
                                  showDialog(
                                      context: context,
                                      builder: (context) {
                                        return AlertDialog(
                                          title: Text(
                                            'Upload',
                                            style: FontTextStyle.Proxima16Medium
                                                .copyWith(
                                                    color:
                                                        ColorUtils.primaryColor,
                                                    fontWeight:
                                                        FontWeightClass.extraB,
                                                    fontSize: 13.sp),
                                          ),
                                          content: Text(
                                              'are you sure want to Upload?',
                                              style:
                                                  FontTextStyle.Proxima16Medium
                                                      .copyWith(
                                                          color: ColorUtils
                                                              .primaryColor)),
                                          actions: [
                                            IconButton(
                                                onPressed: () {
                                                  Get.back();
                                                },
                                                icon: const Icon(
                                                  Icons.cancel,
                                                  color:
                                                      ColorUtils.primaryColor,
                                                )),
                                            IconButton(
                                                onPressed: () {
                                                  Get.back();
                                                  Get.showSnackbar(
                                                    GetSnackBar(
                                                      message:
                                                          "Upload Data Succesfully",
                                                      borderRadius: 10.0,
                                                      margin: EdgeInsets.only(
                                                          left: 4.w,
                                                          right: 4.w,
                                                          bottom: 4.w),
                                                      snackPosition:
                                                          SnackPosition.BOTTOM,
                                                      backgroundColor:
                                                          ColorUtils
                                                              .primaryColor
                                                              .withOpacity(0.9),
                                                      duration: const Duration(
                                                          seconds: 3),
                                                    ),
                                                  );
                                                },
                                                icon: const Icon(
                                                  Icons.check,
                                                  color:
                                                      ColorUtils.primaryColor,
                                                ))
                                          ],
                                        );
                                      });
                                }
                              }),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  _getFromGallery() async {
    PickedFile? pickedFile = await ImagePicker().getImage(
      source: ImageSource.gallery,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        imageFile = File(pickedFile.path);
      });
    }
  }

  _getFromCamera() async {
    PickedFile? pickedFile = await ImagePicker().getImage(
      source: ImageSource.camera,
      maxWidth: 1800,
      maxHeight: 1800,
    );
    if (pickedFile != null) {
      setState(() {
        imageFile = File(pickedFile.path);
      });
    }
  }

  Future chooseImageBottomSheet() {
    return Get.bottomSheet(
        //isScrollControlled: true,
        //isDismissible: true,
        backgroundColor: Colors.white,
        shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20))), StatefulBuilder(
      builder: ((context, setState) {
        return SizedBox(
          height: 34.w,
          child: Padding(
            padding: EdgeInsets.only(top: 1.h, right: 3.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: const Icon(
                    Icons.close,
                    color: ColorUtils.grey,
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Column(
                      children: [
                        InkWell(
                            onTap: () {
                              _getFromGallery();
                            },
                            child: CircleAvatar(
                              backgroundColor: ColorUtils.primaryColor,
                              radius: 25.0,
                              child: Icon(
                                Icons.add_photo_alternate_rounded,
                                color: ColorUtils.white,
                                size: 9.w,
                              ),
                            )),
                        SizeConfig.sH1,
                        Text(
                          "Gallery",
                          style: FontTextStyle.Proxima16Medium.copyWith(
                              color: ColorUtils.primaryColor),
                        )
                      ],
                    ),
                    SizeConfig.sW4,
                    Column(
                      children: [
                        InkWell(
                            onTap: () {
                              _getFromCamera();
                            },
                            child: CircleAvatar(
                              backgroundColor: ColorUtils.primaryColor,
                              radius: 25.0,
                              child: Icon(
                                Icons.camera,
                                color: ColorUtils.white,
                                size: 10.w,
                              ),
                            )),
                        SizeConfig.sH1,
                        Text(
                          "Camera",
                          style: FontTextStyle.Proxima16Medium.copyWith(
                              color: ColorUtils.primaryColor),
                        )
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      }),
    ));
  }
}
