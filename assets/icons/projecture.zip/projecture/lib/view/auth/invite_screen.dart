import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:projecture/utils/size_config_utils.dart';
import 'package:sizer/sizer.dart';

class InviteScreen extends StatefulWidget {
  const InviteScreen({Key? key}) : super(key: key);

  @override
  State<InviteScreen> createState() => _InviteScreenState();
}

class _InviteScreenState extends State<InviteScreen> {
  List<Map<String, dynamic>> inviteList = <Map<String, dynamic>>[
    {"text": 'Stress level'},
    {"text": 'Anger/lrritability'},
    {"text": 'Repressed emotions'},
    {"text": 'Conflict'},
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Project List"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: ScrollConfiguration(
        behavior: const ScrollBehavior().copyWith(overscroll: false),
        child: SingleChildScrollView(
          child: ListView.builder(
              padding: EdgeInsets.zero,
              shrinkWrap: true,
              itemCount: inviteList.length,
              itemBuilder: (BuildContext context, int index) {
                return Column(
                  children: [
                    Padding(
                      padding:
                          EdgeInsets.symmetric(vertical: 2.w, horizontal: 3.w),
                      child: Container(
                        decoration: BoxDecoration(
                            boxShadow: [
                              BoxShadow(
                                color: ColorUtils.greyBB.withOpacity(0.1),
                                spreadRadius: 2,
                                blurRadius: 3,
                                offset: const Offset(
                                    0, 3), // changes position of shadow
                              ),
                            ],
                            borderRadius: BorderRadius.circular(10),
                            color: ColorUtils.white),
                        child: Theme(
                          data: ThemeData(dividerColor: Colors.transparent),
                          child: ExpansionTile(
                            iconColor: ColorUtils.primaryColor,
                            title: Text(
                              inviteList[index]['text'],
                              style: TextStyle(
                                  fontSize: 10.sp,
                                  color: ColorUtils.primaryColor),
                            ),
                            children: <Widget>[
                              SizedBox(
                                width: Get.width,
                                child: Padding(
                                    padding: EdgeInsets.only(bottom: 3.h),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(
                                              left: 8.w, right: 3.w, top: 1.h),
                                          child: Text(
                                            "Amet minium mollit non deserunt uliamoc est sit aliqua dolor do amet sint.Amet minium mollit non deserunt uliamoc est sit aliqua dolor do amet sint.Amet minium mollit n sit aliqua dolor do amet.",
                                            style: TextStyle(fontSize: 10.sp),
                                          ),
                                        ),
                                        SizeConfig.sH1,
                                        Padding(
                                          padding: EdgeInsets.only(right: 2.w),
                                          child: InkWell(
                                            onTap: () {},
                                            child: Align(
                                              alignment: Alignment.bottomRight,
                                              child: Container(
                                                height: 12.w,
                                                width: 30.w,
                                                decoration: const BoxDecoration(
                                                    color: ColorUtils
                                                        .primaryColor,
                                                    borderRadius:
                                                        BorderRadius.all(
                                                            Radius.circular(
                                                                8.0))),
                                                child: Center(
                                                  child: Text(
                                                    "Invite",
                                                    style: FontTextStyle
                                                            .Proxima16Medium
                                                        .copyWith(
                                                            color: ColorUtils
                                                                .white,
                                                            fontWeight:
                                                                FontWeightClass
                                                                    .semiB),
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    )),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                );
              }),
        ),
      ),
    );
  }
}
