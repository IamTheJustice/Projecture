import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:sizer/sizer.dart';

class LeaderGiveTaskScreen extends StatefulWidget {
  const LeaderGiveTaskScreen({Key? key}) : super(key: key);

  @override
  State<LeaderGiveTaskScreen> createState() => _LeaderGiveTaskScreenState();
}

class _LeaderGiveTaskScreenState extends State<LeaderGiveTaskScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Project List"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: ListView.builder(
        shrinkWrap: true,
        scrollDirection: Axis.vertical,
        itemCount: 5,
        itemBuilder: (BuildContext context, int index) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 5.w),
            child: Container(
              height: 24.w,
              width: Get.width,
              decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(10.0)),
                  color: ColorUtils.purple),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      "Firebase project",
                      overflow: TextOverflow.ellipsis,
                      maxLines: 2,
                      style: FontTextStyle.Proxima16Medium.copyWith(
                          color: ColorUtils.white,
                          decoration: TextDecoration.underline),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(
                          "Show Task",
                          style: FontTextStyle.Proxima16Medium.copyWith(
                              color: ColorUtils.white,
                              fontSize: 13.sp,
                              fontWeight: FontWeightClass.semiB),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
