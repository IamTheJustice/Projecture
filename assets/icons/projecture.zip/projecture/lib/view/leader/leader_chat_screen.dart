import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';

class LeaderChatScreen extends StatefulWidget {
  const LeaderChatScreen({Key? key}) : super(key: key);

  @override
  State<LeaderChatScreen> createState() => _LeaderChatScreenState();
}

class _LeaderChatScreenState extends State<LeaderChatScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: Center(
        child: SvgPicture.asset('assets/icons/test.svg'),
      ),
    );
  }
}
