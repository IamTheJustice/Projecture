import 'package:flutter/material.dart';
import 'package:flutter_slidable/flutter_slidable.dart';
import 'package:get/get.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:sizer/sizer.dart';

class LeaderDoneScreen extends StatefulWidget {
  const LeaderDoneScreen({Key? key}) : super(key: key);

  @override
  State<LeaderDoneScreen> createState() => _LeaderDoneScreenState();
}

class _LeaderDoneScreenState extends State<LeaderDoneScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Project List"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: ScrollConfiguration(
        behavior: const ScrollBehavior().copyWith(overscroll: false),
        child: SingleChildScrollView(
          child: ListView.builder(
            shrinkWrap: true,
            scrollDirection: Axis.vertical,
            physics: NeverScrollableScrollPhysics(),
            itemCount: 20,
            itemBuilder: (BuildContext context, int index) {
              return Padding(
                padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 5.w),
                child: Slidable(
                  key: const ValueKey(0),
                  endActionPane: ActionPane(
                    motion: GestureDetector(
                        onTap: () {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      const LeaderShowTaskDone()));
                        },
                        child: Container(
                          height: 18.w,
                          margin: EdgeInsets.only(left: 3.sp),
                          decoration: BoxDecoration(
                            color: ColorUtils.green2A.withOpacity(0.5),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text(
                              "Show \nTask",
                              style: FontTextStyle.Proxima16Medium.copyWith(
                                  color: ColorUtils.white,
                                  fontWeight: FontWeightClass.semiB),
                            ),
                          ),
                        )),
                    extentRatio: .3,
                    dragDismissible: false,
                    children: const [],
                  ),
                  child: Container(
                    height: 18.w,
                    width: Get.width,
                    decoration: const BoxDecoration(
                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                        color: ColorUtils.purple),
                    child: Padding(
                      padding:
                          EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
                      child: Text(
                        "Firebase project",
                        overflow: TextOverflow.ellipsis,
                        maxLines: 2,
                        style: FontTextStyle.Proxima16Medium.copyWith(
                            color: ColorUtils.white,
                            decoration: TextDecoration.underline),
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}

class LeaderShowTaskDone extends StatefulWidget {
  const LeaderShowTaskDone({Key? key}) : super(key: key);

  @override
  State<LeaderShowTaskDone> createState() => _LeaderShowTaskDoneState();
}

class _LeaderShowTaskDoneState extends State<LeaderShowTaskDone> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Show Task"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(vertical: 2.w, horizontal: 3.w),
        child: Container(
          height: 30.w,
          width: 40.w,
          decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                    blurRadius: 9.0,
                    color: ColorUtils.black.withOpacity(0.2),
                    spreadRadius: 0.5),
              ],
              borderRadius: BorderRadius.all(Radius.circular(10.0)),
              color: ColorUtils.purple),
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 5.w, vertical: 3.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  "Firebase project",
                  overflow: TextOverflow.ellipsis,
                  maxLines: 2,
                  style: FontTextStyle.Proxima16Medium.copyWith(
                      color: ColorUtils.white,
                      decoration: TextDecoration.underline),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
