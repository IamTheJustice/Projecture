import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:projecture/utils/size_config_utils.dart';
import 'package:sizer/sizer.dart';

class LeaderWalletScreen extends StatefulWidget {
  const LeaderWalletScreen({Key? key}) : super(key: key);

  @override
  State<LeaderWalletScreen> createState() => _LeaderWalletScreenState();
}

class _LeaderWalletScreenState extends State<LeaderWalletScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Wallet"),
        centerTitle: true,
        backgroundColor: ColorUtils.primaryColor,
        iconTheme: const IconThemeData(color: ColorUtils.white),
      ),
      body: Column(
        children: [
          SizeConfig.sH2,
          Center(
            child: Text(
              "130 Points",
              style: FontTextStyle.Proxima16Medium.copyWith(
                  fontSize: 17.sp,
                  color: ColorUtils.greyCE,
                  fontWeight: FontWeightClass.extraB),
            ),
          ),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 2.h, horizontal: 5.w),
            child: Container(
              height: 10.h,
              width: Get.width,
              decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                        blurRadius: 9.0,
                        spreadRadius: 0.5,
                        color: ColorUtils.black.withOpacity(0.2))
                  ],
                  color: ColorUtils.purple,
                  borderRadius: BorderRadius.all(Radius.circular(20))),
              child: Row(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 5.w),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "FIREBASE AUTHENTICATION",
                          style: FontTextStyle.Proxima14Regular.copyWith(
                              color: ColorUtils.white),
                        ),
                        Text(
                          "IN FLUTTER",
                          style: FontTextStyle.Proxima14Regular.copyWith(
                              color: ColorUtils.white),
                        )
                      ],
                    ),
                  ),
                  Spacer(),
                  Text(
                    "+ 30",
                    style: FontTextStyle.Proxima16Medium.copyWith(
                        color: ColorUtils.green40, fontSize: 13.sp),
                  ),
                  SizeConfig.sW3,
                ],
              ),
            ),
          )
        ],
      ),
    );
  }
}
