import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:projecture/checkbox_controller.dart';
import 'package:projecture/utils/color_utils.dart';
import 'package:projecture/utils/font_style_utils.dart';
import 'package:projecture/utils/size_config_utils.dart';
import 'package:sizer/sizer.dart';

class Testing extends StatefulWidget {
  const Testing({Key? key}) : super(key: key);

  @override
  State<Testing> createState() => _TestingState();
}

class _TestingState extends State<Testing> {
  OrderSummeryViewModel orderSummeryViewModel = Get.find();
  List list1 = ["ABC", "EFG", "HIJ", "KLM"];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          SizeConfig.sH15,
          Text("Language"),
          GetBuilder<OrderSummeryViewModel>(builder: (buttonController) {
            return Wrap(
              alignment: WrapAlignment.start,
              spacing: 6.0,
              children: List.generate(
                  list1.length,
                  (index) => Padding(
                      padding: EdgeInsets.symmetric(
                          vertical: 1.w, horizontal: 0.8.w),
                      child: InkWell(
                        onTap: () {
                          log("Index===$index");
                          buttonController.Selection(value: list1[index]);
                          log('selectionList${buttonController.selection}');
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: buttonController.selection
                                      .contains(list1[index])
                                  ? ColorUtils.purple
                                  : ColorUtils.white,
                              borderRadius: BorderRadius.circular(14),
                              border: Border.all(color: ColorUtils.purple)),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(
                                    left: 4.w,
                                    top: 2.w,
                                    bottom: 2.w,
                                    right: 4.w),
                                child: Text(
                                  list1[index],
                                  style:
                                      FontTextStyle.Proxima14Regular.copyWith(
                                          color: buttonController.selection
                                                  .contains(list1[index])
                                              ? ColorUtils.white
                                              : ColorUtils.purple,
                                          fontWeight: FontWeightClass.medium),
                                ),
                              ),
                              Icon(
                                buttonController.selection
                                        .contains(list1[index])
                                    ? Icons.check_box
                                    : Icons.check_box_outline_blank,
                                color: buttonController.selection
                                        .contains(list1[index])
                                    ? ColorUtils.white
                                    : ColorUtils.purple,
                              ),
                            ],
                          ),
                        ),
                      ))),
            );
          }),
        ],
      ),
    );
  }
}
